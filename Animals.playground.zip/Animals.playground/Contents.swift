import UIKit

class Animal {
    
    //variables
    var  name: String
    var health: Int
    
    //initialization
    init(name: String, health: Int){
        self.name = name
        self.health = 100
    }
    
    //methods
    func displayHealth() {
        print("Heath level for a \(name) =\(health)")
    }
}

//subclasses
class Cat: Animal{
    //Give the Cat a method "growl" that prints to the screen "Rawr!"
    func growl(){
        print("Rawr!")
    }
    //Modify the Cat's health to be 150 aka re-initialization
    init(name: String){
        super.init(name: name, health: 150)
    }
    
   //Give the Cat a method "run" that prints to the screen "Running" and deducts 10 health
    func run(){
        print("Running")
        health -= 10
    }
}//end class

class Cheetah: Cat {
    //Override the Cheetah's run method to print "Running Fast" and deduct 50 health
    override  func run(){
        if self.health > 0 {
        print("Running Fast")
        health -= 50
        } else {
            print("\(name) cant run!! too tired")
        }
    }
    //Add a sleep function to the Cheetah class that adds 50 health, make sure its health doesn't go over 200
    func sleep(){
        if self.health<200{
            self.health += 50
        }
    }
}//end class

class Lion: Cat {
    //Override the growl method of the Lion to make it print "ROAR!!!! I am the King of the Jungle"
    override func growl(){
        print("ROAR!!!! I am the King of the Jungle")
    }
    //Override Lion's health to be 200
    override init(name: String){
        super.init(name: name)
        health = 200
    }
    
}//end class

let cheetah = Cheetah(name: "Cartier")
for i in 1...4{
    cheetah.run()
}
cheetah.displayHealth()

let lion = Lion(name: "Simba")
for i in 1...3{
lion.run()
}
lion.growl()
lion.displayHealth()

